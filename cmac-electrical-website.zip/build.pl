#!/usr/bin/perl
# CMAC Electrical Services: builds the static pages from src/pages + src/partials.
#   perl build.pl
# Edit src/, never the generated .html files in this folder.
#   {{> name}}     include src/partials/name.html
#   {{crumbs}}     breadcrumb built from @crumb
#   {{cur:key}}    aria-current on the nav item matching @cur
# Section numbers (data-cct) are renumbered 00, 01, 02... per page.
# FAQPage JSON-LD is generated from the .fq items on each page.
use strict; use warnings; use utf8; use open qw(:std :utf8);
use File::Basename qw(dirname);
use Cwd qw(abs_path);
my $dir = dirname(abs_path($0));
my $BASE = 'https://cmacelectrical.com.au/';

sub slurp { open my $f,'<:raw:utf8',$_[0] or die "$_[0]: $!"; local $/; my $s=<$f>; close $f; $s }
sub spit { open my $f,'>:raw:utf8',$_[0] or die "$_[0]: $!"; print $f $_[1]; close $f }
sub partial { my $n=shift; slurp("$dir/src/partials/$n.html") }
sub jstr { my $s=shift; $s =~ s/\\/\\\\/g; $s =~ s/"/\\"/g; $s =~ s/\s+/ /g; $s =~ s/^ | $//g; $s }
sub plain { my $s=shift; $s =~ s/<[^>]+>//g; $s =~ s/&amp;/&/g; $s }

opendir(my $d,"$dir/src/pages") or die $!;
my @pages = sort grep { /\.html$/ } readdir $d; closedir $d;

for my $pf (@pages) {
  my $src = slurp("$dir/src/pages/$pf");
  my ($front,$body) = split /^---\n/m, $src, 2;
  die "no front matter: $pf" unless defined $body;
  my %m; for (split /\n/,$front) { $m{$1}=$2 if /^\@(\w+)\s+(.*)$/ }
  my $file = $m{file} or die "no \@file: $pf";
  die "title too long ($file): ".length($m{title}) if length($m{title}) > 60;
  die "description too long ($file): ".length($m{desc}) if length($m{desc}) > 155;
  my $url = $file eq 'index.html' ? $BASE : $BASE.$file;

  # expand partials in the body (one level of nesting is enough here)
  for (1..2) { $body =~ s/\{\{> ([\w-]+)\}\}\n?/partial($1)/ge; }

  my $crumbs = '';
  if ($m{crumb}) {
    $crumbs = qq{<nav class="crumbs" aria-label="Breadcrumb"><a href="index.html">Home</a><span aria-hidden="true">/</span><span aria-current="page">$m{crumb}</span></nav>};
  }
  $body =~ s/\{\{crumbs\}\}/$crumbs/g;
  my $ch2 = $m{contact_h2} || 'Tell us about the job.';
  $body =~ s/\{\{contact_h2\}\}/$ch2/g;
  my $clead = $m{contact_lead} || 'Call, email, or send it through here — photos help, plain English is fine, and you’ll get an upfront answer either way. You’ll deal with Cam, the licence holder, from first call to final certificate.';
  $body =~ s/\{\{contact_lead\}\}/$clead/g;
  my $cextra = $m{contact_extra} ? partial($m{contact_extra}) : '';
  $body =~ s/\{\{contact_extra\}\}/$cextra/g;
  my $fi = $m{form_intro} ? qq{      <p class="cf__intro">$m{form_intro}</p>\n} : '';
  $body =~ s/\{\{form_intro\}\}/$fi/g;
  my $fn = $m{form_note} ? qq{      <p class="cf__note">$m{form_note}</p>\n} : '';
  $body =~ s/\{\{form_note\}\}/$fn/g;

  # section numbers run in page order
  my $n = 0;
  $body =~ s/data-cct="\d\d"/sprintf('data-cct="%02d"',$n++)/ge;

  # structured data
  my $ld = '';
  $ld .= partial('schema-business') if $m{biz};
  $ld .= partial($m{schema}) if $m{schema};
  if ($m{crumb}) {
    my $c = jstr(plain($m{crumb}));
    $ld .= qq{<script type="application/ld+json">{"\@context":"https://schema.org","\@type":"BreadcrumbList","itemListElement":[{"\@type":"ListItem","position":1,"name":"Home","item":"$BASE"},{"\@type":"ListItem","position":2,"name":"$c","item":"$url"}]}</script>\n};
  }
  my @faq;
  while ($body =~ m{<button class="fq__q".*?<span class="fq__n"[^>]*>\d+</span><span>(.*?)</span></button></h3><div class="fq__a"[^>]*>(.*?)</div></div>}sg) {
    my ($q,$a) = (jstr(plain($1)),jstr(plain($2)));
    push @faq, qq{{"\@type":"Question","name":"$q","acceptedAnswer":{"\@type":"Answer","text":"$a"}}};
  }
  if (@faq) { $ld .= '<script type="application/ld+json">{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[' . join(',',@faq) . ']}</script>' . "\n"; }

  my $esc_title = $m{title}; $esc_title =~ s/&(?!amp;)/&amp;/g;
  my $esc_desc = $m{desc}; $esc_desc =~ s/&(?!amp;)/&amp;/g;
  my $img = $BASE.$m{hero};

  my $head = <<"H";
<!doctype html>
<html lang="en-AU">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>$esc_title</title>
<meta name="description" content="$esc_desc">
<link rel="canonical" href="$url">
<meta name="theme-color" content="#101823">
<meta property="og:title" content="$esc_title">
<meta property="og:description" content="$esc_desc">
<meta property="og:type" content="website">
<meta property="og:url" content="$url">
<meta property="og:image" content="$img">
<script>document.documentElement.classList.add('js')</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Albert+Sans:wght\@400;500;600;700&family=Plus+Jakarta+Sans:wght\@400;500;600;700;800&family=Saira:wdth,wght\@75..125,500..900&family=Unbounded:wght\@600;700;800&display=swap" rel="stylesheet">
<link rel="preload" as="image" href="$m{hero}" fetchpriority="high">
<link rel="stylesheet" href="css/style.css">
$ld</head>
<body>

H
  my $out = $head . partial('sprite') . qq{<a class="skip" href="#main">Skip to content</a>\n\n} . partial('header') . partial('feed')
    . qq{\n<main id="main">\n$body</main>\n\n} . partial('footer') . "</body>\n</html>\n";

  # nav state
  $out =~ s/\{\{cur:(\w+)\}\}/ $1 eq ($m{cur}||'') ? ' aria-current="page"' : '' /ge;
  $out =~ s/href="#quote"/href="#enquire"/g if $m{no_hero_form};
  die "unresolved token in $file: $1" if $out =~ /(\{\{[^}]*\}\})/;
  spit("$dir/$file",$out);
  printf "%-14s %d bytes, %d FAQ\n",$file,length($out),scalar(@faq);
}
