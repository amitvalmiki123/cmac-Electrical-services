/* CMAC Electrical Services homepage. Each feature keeps its own scope. */
(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Header + drawer ---------- */
  (function header() {
    var hdr = $('#hdr'), burger = $('#burger'), drawer = $('#drawer');
    function onScroll() { hdr.classList.toggle('is-stuck', window.scrollY > 60); }
    window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
    function setOpen(open) {
      drawer.classList.toggle('is-open', open);
      drawer.setAttribute('aria-hidden', String(!open));
      burger.setAttribute('aria-expanded', String(open));
      document.body.style.overflow = open ? 'hidden' : '';
    }
    burger.addEventListener('click', function () { setOpen(true); });
    $$('[data-close-drawer]', drawer).forEach(function (el) { el.addEventListener('click', function () { setOpen(false); }); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setOpen(false); });
  })();

  /* ---------- Reveal (observer + scroll sweep, because observers can miss) ---------- */
  (function reveal() {
    var items = $$('.rv, .mos');
    function sweep() {
      var vh = window.innerHeight;
      items = items.filter(function (el) {
        if (el.hidden || !el.getClientRects().length) return true;
        var r = el.getBoundingClientRect();
        if (r.top < vh * 0.94 && r.bottom > 0) { el.classList.add('is-in'); return false; }
        return true;
      });
    }
    window.addEventListener('scroll', sweep, { passive: true });
    window.addEventListener('resize', sweep);
    window.addEventListener('load', sweep);
    sweep();
  })();

  /* ---------- Feed conduit: draws as you scroll, energises each tag ---------- */
  (function feed() {
    var svg = $('#feed');
    if (!svg) return;
    var NS = 'http://www.w3.org/2000/svg';
    var live, table = [], stops = [], built = false, raf = 0;

    function rounded(pts, r) {
      var d = 'M' + pts[0][0] + ' ' + pts[0][1];
      for (var i = 1; i < pts.length - 1; i++) {
        var p = pts[i], a = pts[i - 1], b = pts[i + 1];
        var la = Math.hypot(p[0] - a[0], p[1] - a[1]), lb = Math.hypot(b[0] - p[0], b[1] - p[1]);
        var rr = Math.min(r, la / 2, lb / 2);
        if (!rr) { d += 'L' + p[0] + ' ' + p[1]; continue; }
        var ax = p[0] + (a[0] - p[0]) / la * rr, ay = p[1] + (a[1] - p[1]) / la * rr;
        var bx = p[0] + (b[0] - p[0]) / lb * rr, by = p[1] + (b[1] - p[1]) / lb * rr;
        d += 'L' + ax + ' ' + ay + 'Q' + p[0] + ' ' + p[1] + ' ' + bx + ' ' + by;
      }
      var e = pts[pts.length - 1];
      return d + 'L' + e[0] + ' ' + e[1];
    }
    function el(tag, attrs) {
      var n = document.createElementNS(NS, tag);
      Object.keys(attrs).forEach(function (k) { n.setAttribute(k, attrs[k]); });
      return n;
    }
    function build() {
      if (getComputedStyle(svg).display === 'none') { built = false; return; }
      svg.innerHTML = '';
      var docH = document.documentElement.scrollHeight, W = document.documentElement.clientWidth;
      svg.setAttribute('width', W); svg.setAttribute('height', docH);
      svg.setAttribute('viewBox', '0 0 ' + W + ' ' + docH);
      svg.style.height = docH + 'px';
      var wrap = $('.hero .wrap').getBoundingClientRect();
      var xL = Math.max(14, wrap.left / 2), xR = Math.min(W - 14, wrap.right + (W - wrap.right) / 2);
      var nodes = $$('.tag[data-node]');
      var pts = [], spurs = [], side = 'l';
      nodes.forEach(function (tag, i) {
        var want = tag.getAttribute('data-node'), r = tag.getBoundingClientRect();
        var y = Math.round(r.top + r.height / 2 + window.scrollY);
        if (want === 'end') want = side;
        var x = want === 'l' ? xL : xR;
        if (i === 0) { pts.push([x, y]); side = want; }
        else if (want !== side) {
          var sec = tag.closest('section').getBoundingClientRect();
          var seam = Math.round(sec.top + window.scrollY + Math.min(34, (r.top - sec.top) / 2));
          pts.push([side === 'l' ? xL : xR, seam], [x, seam], [x, y]);
          side = want;
        } else { pts.push([x, y]); }
        // Right-hand tags sit at their column start: feed them from their own edge
        var endX = want === 'l' ? r.left - 4 : r.right + 4;
        if (want === 'r' && r.left > W / 2 && r.right < wrap.right - 80) endX = r.right + 4;
        spurs.push({ tag: tag, y: y, d: 'M' + x + ' ' + y + 'L' + Math.round(endX) + ' ' + y, x: x });
      });
      var d = rounded(pts, 26);
      svg.appendChild(el('path', { 'class': 'feed__track', d: d }));
      spurs.forEach(function (s) {
        s.path = el('path', { 'class': 'feed__spur', d: s.d }); svg.appendChild(s.path);
        s.dot = el('circle', { 'class': 'feed__node', cx: s.x, cy: s.y, r: 6 }); svg.appendChild(s.dot);
      });
      live = el('path', { 'class': 'feed__live', d: d }); svg.appendChild(live);
      var len = live.getTotalLength();
      live.style.strokeDasharray = len; live.style.strokeDashoffset = len;
      table = [];
      for (var t = 0; t <= 240; t++) { var at = len * t / 240, pt = live.getPointAtLength(at); table.push([at, pt.y]); }
      stops = spurs; built = true; live.__len = len;
      update();
    }
    function update() {
      raf = 0;
      if (!built) return;
      var target = window.scrollY + window.innerHeight * 0.68, drawn = 0;
      for (var i = 0; i < table.length; i++) { if (table[i][1] <= target) drawn = table[i][0]; else break; }
      live.style.strokeDashoffset = live.__len - drawn;
      stops.forEach(function (s) {
        var on = s.y <= target;
        s.path.classList.toggle('is-live', on); s.dot.classList.toggle('is-live', on); s.tag.classList.toggle('is-live', on);
      });
    }
    window.addEventListener('scroll', function () { if (!raf) raf = requestAnimationFrame(update); }, { passive: true });
    var timer;
    function later() { clearTimeout(timer); timer = setTimeout(build, 180); }
    window.addEventListener('resize', later);
    window.addEventListener('load', later);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(later);
    if ('ResizeObserver' in window) new ResizeObserver(later).observe(document.body);
    later();
  })();

  /* ---------- Subtle parallax ---------- */
  (function parallax() {
    if (reduced) return;
    var items = $$('[data-px]').map(function (el) { return { el: el, k: parseFloat(el.getAttribute('data-px')) }; });
    if (!items.length) return;
    var tick = false;
    function run() {
      tick = false;
      if (window.innerWidth < 1025) { items.forEach(function (i) { i.el.style.translate = ''; }); return; }
      var vh = window.innerHeight;
      items.forEach(function (i) {
        var r = i.el.getBoundingClientRect();
        if (r.bottom < -200 || r.top > vh + 200) return;
        i.el.style.translate = '0 ' + (((r.top + r.height / 2) - vh / 2) * i.k).toFixed(1) + 'px';
      });
    }
    window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(run); } }, { passive: true });
    run();
  })();

  /* ---------- Service breakers (tabs) ---------- */
  (function services() {
    var tabs = $$('.stile'), panels = $$('.spanel');
    if (!tabs.length) return;
    function select(i, opts) {
      tabs.forEach(function (t, k) {
        var on = k === i;
        t.classList.toggle('is-on', on);
        t.setAttribute('aria-selected', String(on));
        t.tabIndex = on ? 0 : -1;
        panels[k].hidden = !on;
        panels[k].classList.toggle('is-enter', on);
      });
      if (opts && opts.focus) tabs[i].focus();
      if (opts && opts.scroll && window.innerWidth < 1025) {
        var top = panels[i].getBoundingClientRect().top + window.scrollY - 100;
        window.scrollTo({ top: top, behavior: reduced ? 'auto' : 'smooth' });
      }
      window.dispatchEvent(new Event('resize'));
    }
    tabs.forEach(function (t, i) {
      t.addEventListener('click', function () { select(i, { scroll: true }); });
      t.addEventListener('keydown', function (e) {
        var n = tabs.length, to = null;
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') to = (i + 1) % n;
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') to = (i - 1 + n) % n;
        if (e.key === 'Home') to = 0;
        if (e.key === 'End') to = n - 1;
        if (to !== null) { e.preventDefault(); select(to, { focus: true }); }
      });
    });
    $$('[data-open-svc]').forEach(function (a) {
      a.addEventListener('click', function () { select(parseInt(a.getAttribute('data-open-svc'), 10) - 1); });
    });
    select(0);
    panels[0].classList.remove('is-enter');
  })();

  /* ---------- Forms: each completed field closes part of the circuit ---------- */
  (function forms() {
    $$('[data-form]').forEach(function (form) {
      var fields = $$('.fld', form).filter(function (f) { return !f.querySelector('[type=file]'); });
      var bars = $$('.qf__circuit i', form);
      function filled(f) { var c = f.querySelector('input,select,textarea'); return c && String(c.value).trim() !== ''; }
      function refresh() {
        var n = 0;
        fields.forEach(function (f) { var on = filled(f); f.classList.toggle('is-live', on); if (on) { n++; f.classList.remove('is-bad'); } });
        bars.forEach(function (b, i) { b.classList.toggle('is-live', i < n); });
      }
      form.addEventListener('input', refresh);
      form.addEventListener('change', refresh);
      var file = form.querySelector('[type=file]');
      if (file) file.addEventListener('change', function () {
        var lab = form.querySelector('[data-upload-label]');
        lab.textContent = file.files.length ? file.files.length + (file.files.length === 1 ? ' photo attached' : ' photos attached') : 'Photos welcome — attach them here';
      });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var firstBad = null;
        fields.forEach(function (f) {
          var c = f.querySelector('input,select,textarea');
          var bad = c.required && !filled(f);
          f.classList.toggle('is-bad', bad);
          c.setAttribute('aria-invalid', String(bad));
          if (bad && !firstBad) firstBad = c;
        });
        if (firstBad) { firstBad.focus(); return; }
        bars.forEach(function (b) { b.classList.add('is-live'); });
        form.querySelector('.qf__ok').hidden = false;
      });
    });
  })();

  /* ---------- Smoke alarm: countdown + test the interconnect ---------- */
  (function smoke() {
    var box = $('#smoke-count');
    if (box) {
      var b = box.querySelector('[data-days]'), lab = box.querySelector('[data-days-label]');
      var days = Math.ceil((new Date(2027, 0, 1) - new Date()) / 86400000);
      if (days > 0) { b.textContent = days; lab.textContent = days === 1 ? 'day to the deadline' : 'days to the deadline'; }
      else { b.textContent = 'Now'; lab.textContent = 'in force for every home'; }
    }
    var house = $('#house'), btn = $('#alarm-test'), timer;
    if (!house) return;
    function fire() {
      house.classList.remove('is-ringing');
      void house.getBoundingClientRect();
      house.classList.add('is-ringing');
      clearTimeout(timer);
      timer = setTimeout(function () { house.classList.remove('is-ringing'); }, 3800);
    }
    if (btn) btn.addEventListener('click', fire);
    $$('[data-alarm]', house).forEach(function (a) { a.addEventListener('click', fire); });
    if (!reduced) {
      var done = false;
      window.addEventListener('scroll', function once() {
        if (done) return;
        var r = house.getBoundingClientRect();
        if (r.top < window.innerHeight * 0.6 && r.bottom > 0) { done = true; fire(); window.removeEventListener('scroll', once); }
      }, { passive: true });
    }
  })();

  /* ---------- Why: test sheet tracks the scroll, the meter reads it ---------- */
  (function tests() {
    var rows = $$('.test'), txt = $('#meter-txt'), needle = $('#meter-needle');
    if (!rows.length) return;
    var current = -1, tick = false;
    function run() {
      tick = false;
      var mid = window.innerHeight * 0.55, idx = 0;
      rows.forEach(function (r, i) { if (r.getBoundingClientRect().top < mid) idx = i; });
      if (idx === current) return;
      current = idx;
      rows.forEach(function (r, i) { r.classList.toggle('is-on', i === idx); r.classList.toggle('is-done', i < idx); });
      if (txt) txt.textContent = 'PASS';
      if (needle) needle.style.transform = 'rotate(' + (-70 + idx * 35) + 'deg)';
    }
    window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(run); } }, { passive: true });
    run();
  })();

  /* ---------- Before / after ---------- */
  (function compare() {
    var ba = $('#ba'), range = $('#ba-range');
    if (!ba) return;
    range.addEventListener('input', function () { ba.style.setProperty('--pos', range.value + '%'); });
    var sets = {
      board: {
        before: 'images/switchboard-before-old-meter-box.jpg', after: 'images/switchboard-after-rcbo-upgrade-meter-box.jpg',
        beforeAlt: 'Before: older meter box with separate meters and old protection devices', afterAlt: 'After: modern switchboard with RCBO protection inside the same meter box',
        pos: '50% 58%', title: 'Same box. A different level of safety.',
        text: 'A modern board with individual safety switches on every circuit is the single best safety investment in an older property. Every upgrade includes testing of every circuit, a labelled board, and your Certificate of Compliance issued with the invoice.'
      },
      kitchen: {
        before: 'images/kitchen-renovation-before-electrical-rough-in.jpg', after: 'images/kitchen-renovation-after-led-island-lighting.jpg',
        beforeAlt: 'Before: kitchen stripped back to the frame during renovation', afterAlt: 'After: finished kitchen with downlights, under-cabinet lighting and a glowing island toe-kick',
        pos: '50% 72%', title: 'Lighting designed for the space, from the drawings up.',
        text: 'For renovations we work from the drawings up: lighting designed for the space, power where you’ll use it, and finishes that suit the build. Get us in at the planning stage. Moving a circuit on paper is free; moving it after the plaster’s up isn’t.'
      }
    };
    var bImg = $('#ba-before'), aImg = $('#ba-after');
    $$('[data-ba]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var s = sets[btn.getAttribute('data-ba')];
        $$('[data-ba]').forEach(function (x) { var on = x === btn; x.classList.toggle('is-on', on); x.setAttribute('aria-pressed', String(on)); });
        bImg.src = s.before; aImg.src = s.after; bImg.alt = s.beforeAlt; aImg.alt = s.afterAlt;
        bImg.style.objectPosition = aImg.style.objectPosition = s.pos;
        $('#ba-title').textContent = s.title; $('#ba-text').textContent = s.text;
        var start = btn.getAttribute('data-ba') === 'board' ? 34 : 50; range.value = start; ba.style.setProperty('--pos', start + '%');
      });
    });
  })();

  /* ---------- Gallery filter + lightbox ---------- */
  (function gallery() {
    var tiles = $$('.mos');
    $$('[data-filter]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var f = btn.getAttribute('data-filter');
        $$('[data-filter]').forEach(function (x) { var on = x === btn; x.classList.toggle('is-on', on); x.setAttribute('aria-pressed', String(on)); });
        tiles.forEach(function (t) { t.hidden = !(f === 'all' || t.getAttribute('data-cat') === f); });
        window.dispatchEvent(new Event('scroll'));
        window.dispatchEvent(new Event('resize'));
      });
    });
    var lb = $('#lightbox');
    if (!lb || !lb.showModal) return;
    var img = $('#lb-img'), cap = $('#lb-cap'), index = 0;
    function visible() { return tiles.filter(function (t) { return !t.hidden; }); }
    function show(i) {
      var list = visible(); index = (i + list.length) % list.length;
      var btn = list[index].querySelector('button'), thumb = btn.querySelector('img');
      img.src = btn.getAttribute('data-full'); img.alt = thumb.alt;
      cap.textContent = thumb.alt;
    }
    tiles.forEach(function (t) {
      t.querySelector('button').addEventListener('click', function () { show(visible().indexOf(t)); lb.showModal(); });
    });
    $('#lb-close').addEventListener('click', function () { lb.close(); });
    $('#lb-prev').addEventListener('click', function () { show(index - 1); });
    $('#lb-next').addEventListener('click', function () { show(index + 1); });
    lb.addEventListener('click', function (e) { if (e.target === lb) lb.close(); });
    lb.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') show(index - 1);
      if (e.key === 'ArrowRight') show(index + 1);
    });
  })();

  /* ---------- Service-area circuit schedule (SVG one-line diagram) ---------- */
  var schedule = (function () {
    var svg = $('#sched');
    if (!svg) return { select: function () {} };
    var NS = 'http://www.w3.org/2000/svg';
    var BUS_X = 350, SRC_Y = 286;
    var data = [
      { id: 'brisbane',   n: 1,  label: 'Brisbane',      x: 110, y: 44,  anchor: 'start' },
      { id: 'redlands',   n: 10, label: 'Redlands',      x: 590, y: 66,  anchor: 'end' },
      { id: 'ipswich',    n: 9,  label: 'Ipswich',       x: 60,  y: 128, anchor: 'start' },
      { id: 'underwood',  n: 5,  label: 'Underwood',     x: 560, y: 150, anchor: 'end' },
      { id: 'logan',      n: 2,  label: 'Logan',         x: 190, y: 212, anchor: 'start' },
      { id: 'springwood', n: 4,  label: 'Springwood',    x: 630, y: 234, anchor: 'end' },
      { id: 'browns',     n: 8,  label: 'Browns Plains', x: 100, y: 350, anchor: 'start' },
      { id: 'shailer',    n: 6,  label: 'Shailer Park',  x: 590, y: 352, anchor: 'end' },
      { id: 'beenleigh',  n: 7,  label: 'Beenleigh',     x: 170, y: 450, anchor: 'start' },
      { id: 'goldcoast',  n: 3,  label: 'Gold Coast',    x: 610, y: 500, anchor: 'end' }
    ];
    function el(tag, attrs, parent) {
      var n = document.createElementNS(NS, tag);
      for (var k in attrs) n.setAttribute(k, attrs[k]);
      if (parent) parent.appendChild(n);
      return n;
    }
    el('path', { 'class': 's-bus', d: 'M' + BUS_X + ' 30V530' }, svg);
    var groups = {};
    data.forEach(function (a, i) {
      var g = el('g', { 'class': 's-group', 'data-area': a.id }, svg);
      var dir = a.y < SRC_Y ? -1 : 1, sx = a.x < BUS_X ? -1 : 1, r = 16;
      var d = 'M' + BUS_X + ' ' + SRC_Y + 'V' + (a.y - dir * r) + 'Q' + BUS_X + ' ' + a.y + ' ' + (BUS_X + sx * r) + ' ' + a.y + 'H' + a.x;
      el('path', { 'class': 's-wire', d: 'M' + BUS_X + ' ' + a.y + 'H' + a.x }, g);
      var pulse = el('path', { 'class': 's-pulse', d: d }, g);
      pulse.style.animationDelay = (-i * 0.42) + 's';
      var node = el('g', { 'class': 's-node' }, g);
      el('circle', { cx: a.x, cy: a.y, r: 13 }, node);
      var lbl = el('text', { 'class': 's-lbl', x: a.x + sx * -1 * 0, y: a.y - 32, style: 'text-anchor:' + (a.x < BUS_X ? 'start' : 'end') }, node);
      lbl.setAttribute('x', a.x < BUS_X ? a.x - 18 : a.x + 18);
      lbl.textContent = a.label;
      g.addEventListener('mouseenter', function () { select(a.id); });
      g.addEventListener('click', function () { select(a.id); });
      groups[a.id] = g;
    });
    var src = el('g', { 'class': 's-src' }, svg);
    el('circle', { cx: BUS_X, cy: SRC_Y, r: 28 }, src);
    var bolt = el('path', { d: 'M14.200 1.500 4.600 13.400h6l-1.900 9.100 10.700-13h-6.300z', transform: 'translate(' + (BUS_X - 15) + ' ' + (SRC_Y - 15) + ') scale(1.25)' }, src);
    bolt.setAttribute('aria-hidden', 'true');
    var srcText = el('text', { x: BUS_X - 42, y: SRC_Y }, src); srcText.textContent = 'Loganholme';

    function select(id) {
      Object.keys(groups).forEach(function (k) { groups[k].classList.toggle('is-on', k === id); });
    }
    var order = data.map(function (d) { return d.id; }), at = order.indexOf('logan'), held = false;
    svg.addEventListener('mouseenter', function () { held = true; });
    svg.addEventListener('mouseleave', function () { held = false; });
    select('logan');
    if (!reduced) setInterval(function () { if (held || document.hidden) return; at = (at + 1) % order.length; select(order[at]); }, 2200);
    return { select: select };
  })();

  /* ---------- Reviews: one at a time, auto-advancing, pauses on hover/focus ---------- */
  (function reviews() {
    var stage = $('#rev-stage');
    if (!stage) return;
    var slides = $$('.rev', stage), btns = $$('.rnav', stage), now = 0, timer;
    function show(i) {
      now = i;
      slides.forEach(function (s, k) { s.classList.toggle('is-on', k === i); });
      btns.forEach(function (b, k) { var on = k === i; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', String(on)); });
    }
    function stop() { clearInterval(timer); stage.classList.remove('is-auto'); }
    function play() {
      if (reduced) return;
      stop();
      void stage.offsetWidth;
      stage.classList.add('is-auto');
      timer = setInterval(function () {
        if (document.hidden) return;
        stage.classList.remove('is-auto');
        show((now + 1) % slides.length);
        void stage.offsetWidth;
        stage.classList.add('is-auto');
      }, 7000);
    }
    btns.forEach(function (b, i) { b.addEventListener('click', function () { show(i); play(); }); });
    stage.addEventListener('mouseenter', stop);
    stage.addEventListener('mouseleave', play);
    stage.addEventListener('focusin', stop);
    stage.addEventListener('focusout', play);
    play();
  })();

  /* ---------- FAQ: desktop keeps one answer showing; phones can close it ---------- */
  (function faq() {
    var items = $$('.fq');
    if (!items.length) return;
    function wide() { return window.innerWidth >= 1025; }
    function set(item, on) {
      item.classList.toggle('is-open', on);
      item.querySelector('.fq__q').setAttribute('aria-expanded', String(on));
    }
    items.forEach(function (item) {
      item.querySelector('.fq__q').addEventListener('click', function () {
        var was = item.classList.contains('is-open');
        items.forEach(function (x) { set(x, false); });
        set(item, wide() ? true : !was);
      });
    });
    window.addEventListener('resize', function () {
      if (wide() && !$('.fq.is-open')) set(items[0], true);
    });
  })();

  /* ---------- Interactive Leaflet map, lazy loaded ---------- */
  (function mapInit() {
    var host = $('#leaflet');
    if (!host) return;
    var started = false;
    var HOME = [-27.683, 153.183];
    var places = {
      loganholme: { c: HOME, z: 10 },
      brisbane: { c: [-27.468, 153.024], z: 11, big: 1, t: 'Brisbane' },
      logan: { c: [-27.639, 153.109], z: 12, t: 'Logan' },
      goldcoast: { c: [-28.003, 153.43], z: 11, big: 1, t: 'Gold Coast' },
      springwood: { c: [-27.613, 153.128], z: 13, t: 'Springwood' },
      underwood: { c: [-27.606, 153.111], z: 13, t: 'Underwood' },
      shailer: { c: [-27.66, 153.177], z: 13, t: 'Shailer Park' },
      beenleigh: { c: [-27.716, 153.196], z: 13, t: 'Beenleigh' },
      browns: { c: [-27.662, 153.037], z: 13, t: 'Browns Plains' },
      ipswich: { c: [-27.614, 152.76], z: 11, big: 1, t: 'Ipswich (projects)' },
      redlands: { c: [-27.526, 153.264], z: 12, big: 1, t: 'Redlands' }
    };
    function load(cb) {
      var css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'css/vendor/leaflet.css'; document.head.appendChild(css);
      var s = document.createElement('script'); s.src = 'js/vendor/leaflet.js'; s.onload = cb; document.head.appendChild(s);
    }
    function build() {
      var L = window.L;
      var map = L.map(host, { scrollWheelZoom: false, zoomControl: true, attributionControl: true }).setView([-27.72, 153.15], 10);
      var wide = window.innerWidth >= 1025;
      map.zoomControl.setPosition('bottomright');
      map.attributionControl.setPrefix('<a href="https://leafletjs.com" target="_blank" rel="noopener">Leaflet</a>');
      var base = 'https://services.arcgisonline.com/arcgis/rest/services/Canvas/';
      L.tileLayer(base + 'World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}', { maxZoom: 16, attribution: 'Tiles &copy; Esri, HERE, Garmin, FAO, NOAA, USGS, &copy; OpenStreetMap contributors' }).addTo(map);
      [18000, 36000, 54000].forEach(function (r) {
        L.circle(HOME, { radius: r, color: '#0A6CE8', weight: 1.5, opacity: .45, dashArray: '4 10', fillColor: '#3FA2F5', fillOpacity: .07, className: 'map-ring', interactive: false }).addTo(map);
      });
      var wires = {}, marks = {};
      Object.keys(places).forEach(function (id) {
        var p = places[id];
        if (id === 'loganholme') return;
        wires[id] = L.polyline([HOME, p.c], { color: '#0A6CE8', weight: 2, opacity: .6, className: 'map-wire', interactive: false }).addTo(map);
        var icon = L.divIcon({ className: '', html: '<div class="mk" data-mk="' + id + '"></div>', iconSize: [18, 18], iconAnchor: [9, 9] });
        marks[id] = L.marker(p.c, { icon: icon, title: p.t, alt: p.t }).addTo(map)
          .bindTooltip(p.t, { className: 'mk-tip', direction: 'top', offset: [0, -10], permanent: !!p.big })
          .on('click', function () { focus(id, false); });
      });
      L.marker(HOME, { icon: L.divIcon({ className: '', html: '<div class="mk-src"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M14.200 1.500 4.600 13.400h6l-1.900 9.100 10.700-13h-6.300z"/></svg></div>', iconSize: [46, 46], iconAnchor: [23, 23] }), title: 'CMAC Electrical Services, Loganholme', alt: 'CMAC Electrical Services, Loganholme', zIndexOffset: 500 })
        .addTo(map).bindTooltip('CMAC, Loganholme', { className: 'mk-tip', direction: 'top', offset: [0, -24] });

      function fit(animated) {
        var bounds = L.latLngBounds([places.ipswich.c, places.goldcoast.c, places.brisbane.c, places.redlands.c]);
        var opt = wide ? { paddingTopLeft: [Math.min(470, window.innerWidth * .4), 150], paddingBottomRight: [40, 40], animate: animated } : { padding: [28, 28], animate: animated };
        map.fitBounds(bounds, opt);
      }
      function focus(id, scrollTo) {
        var chips = $$('.mchip');
        chips.forEach(function (c) { c.classList.toggle('is-on', c.getAttribute('data-area') === id); });
        $$('.mk', host).forEach(function (m) { m.classList.toggle('is-on', m.getAttribute('data-mk') === id); });
        Object.keys(wires).forEach(function (k) {
          wires[k].setStyle(k === id ? { color: '#0A6CE8', weight: 4, opacity: 1 } : { color: '#0A6CE8', weight: 2, opacity: id === 'loganholme' ? .6 : .25 });
        });
        if (id === 'loganholme') { fit(!reduced); }
        else {
          var bounds = L.latLngBounds([HOME, places[id].c]).pad(.25);
          var opt = wide ? { paddingTopLeft: [Math.min(470, window.innerWidth * .4), 110], paddingBottomRight: [40, 40], maxZoom: 12, animate: !reduced } : { padding: [36, 36], maxZoom: 12, animate: !reduced };
          map.fitBounds(bounds, opt);
          marks[id].openTooltip();
        }
        if (scrollTo) $('#map').scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'center' });
        if (id !== 'loganholme') schedule.select(id);
      }
      $$('.mchip').forEach(function (c) { c.addEventListener('click', function () { var cov = $('[data-map-mode="cover"]'); if (cov) cov.click(); focus(c.getAttribute('data-area'), false); }); });
      window.__cmacMap = focus;
      window.__cmacLeaflet = map;
      map.on('focus click', function () { map.scrollWheelZoom.enable(); });
      map.on('mouseout', function () { map.scrollWheelZoom.disable(); });
      fit(false);
      setTimeout(function () { map.invalidateSize(); fit(false); }, 300);
    }
    function start() { if (started) return; started = true; load(build); }
    window.addEventListener('scroll', function near() {
      if (started) return;
      if (host.getBoundingClientRect().top < window.innerHeight * 2) start();
    }, { passive: true });
    window.addEventListener('load', function () { setTimeout(start, 1200); });

    // Google Maps view: the iframe only loads when asked for
    var gframe = $('#gmap'), GSRC = 'https://maps.google.com/maps?q=CMAC%20Electrical%20Services%20Loganholme%20QLD&z=11&output=embed';
    $$('[data-map-mode]').forEach(function (b) {
      b.addEventListener('click', function () {
        var google = b.getAttribute('data-map-mode') === 'google';
        $$('[data-map-mode]').forEach(function (x) { var on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-pressed', String(on)); });
        if (google && !gframe.getAttribute('src')) gframe.src = GSRC;
        gframe.hidden = !google;
        if (!google && window.__cmacLeaflet) window.__cmacLeaflet.invalidateSize();
      });
    });
  })();
})();
